import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HangmanGame extends Application {

    // GUI Components
    private Label wordDisplay;    // Display the word with dashes for unguessed letters
    private TextField guessInput; // Input field for the user's guess
    private Label messageLabel;   // Display messages (e.g., correct/incorrect guess, game status)

    // Game State
    private List<String> wrongGuesses = new ArrayList<>();
    private String secretWord = "APPLE"; // Example secret word
    private StringBuilder displayedWord = new StringBuilder("_ _ _ _ _"); // Initial display
    
    @Override
    public void start(Stage primaryStage) {
        // Set up the word display (initially with underscores or dashes)
        wordDisplay = new Label(displayedWord.toString());
        wordDisplay.setStyle("-fx-font-size: 24px;");

        // Set up the input field for guesses
        guessInput = new TextField();
        guessInput.setPromptText("Enter a letter");
        guessInput.setMaxWidth(50);

        // Set up message label for game status
        messageLabel = new Label("Start guessing!");

        // Create buttons
        Button submitButton = new Button("Submit Guess");
        Button restartButton = new Button("Restart Game");

        // Event: Submit Guess
        submitButton.setOnAction(e -> handleGuess());

        // Event: Restart Game
        restartButton.setOnAction(e -> restartGame());

        // Set up layout
        VBox layout = new VBox(10, wordDisplay, guessInput, submitButton, messageLabel, restartButton);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-padding: 20px;");

        // Set up the scene
        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setTitle("Hangman Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Event handler for submitting a guess
    private void handleGuess() {
        String guess = guessInput.getText().toUpperCase();
        if (guess.isEmpty() || guess.length() != 1 || !Character.isLetter(guess.charAt(0))) {
            messageLabel.setText("Please enter a valid letter.");
            return;
        }

        // Check if the guessed letter is in the secret word
        if (secretWord.contains(guess)) {
            updateWordDisplay(guess); // Update the word display for correct guesses
        } else {
            wrongGuesses.add(guess); // Track incorrect guesses
            messageLabel.setText("Incorrect! Wrong guesses: " + wrongGuesses);
        }

        // Check if the player has won or lost
        checkGameStatus();

        // Clear the input field for the next guess
        guessInput.clear();
    }

    // Update the displayed word with the correct guess
    private void updateWordDisplay(String guess) {
        for (int i = 0; i < secretWord.length(); i++) {
            if (secretWord.charAt(i) == guess.charAt(0)) {
                displayedWord.setCharAt(i * 2, guess.charAt(0)); // Update corresponding letter
            }
        }
        wordDisplay.setText(displayedWord.toString());
    }

    // Check if the player has won or lost
    private void checkGameStatus() {
        if (!displayedWord.toString().contains("_")) {
            messageLabel.setText("You won!");
        } else if (wrongGuesses.size() >= 6) { // Example limit of 6 wrong guesses
            messageLabel.setText("Game over! The word was: " + secretWord);
            guessInput.setDisable(true); // Disable further input
        }
    }

    // Event handler for restarting the game
    private void restartGame() {
        displayedWord = new StringBuilder("_ _ _ _ _");
        wordDisplay.setText(displayedWord.toString());
        messageLabel.setText("Game restarted. Start guessing!");
        guessInput.clear();
        guessInput.setDisable(false);
        wrongGuesses.clear(); // Clear wrong guesses
    }

    public static void main(String[] args) {
        launch(args);
    }
}
