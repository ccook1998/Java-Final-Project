public class HangmanGameTest {
    public static void main(String[] args) {
        // Step 1: Initialize the game with a known word
        HangmanLogic game = new HangmanLogic("apple");

        // Step 2: Test guessing a correct letter
        assert game.guessLetter('a') == true : "Correct guess test failed";
        assert game.getDisplayedWord().equals("A _ _ _ _ ") : "Displayed word update failed for correct guess";

        // Step 3: Test guessing an incorrect letter
        assert game.guessLetter('z') == false : "Incorrect guess test failed";
        assert game.getRemainingAttempts() == 5 : "Remaining attempts test failed";

        // Step 4: Test game won condition
        game.guessLetter('p');
        game.guessLetter('l');
        game.guessLetter('e');
        assert game.isGameWon() == true : "Game won condition test failed";

        // Step 5: Test game over condition
        HangmanLogic game2 = new HangmanLogic("orange");
        game2.guessLetter('z');
        game2.guessLetter('x');
        game2.guessLetter('q');
        game2.guessLetter('r');
        game2.guessLetter('t');
        game2.guessLetter('y');
        assert game2.isGameOver() == true : "Game over condition test failed";

        // Output success message
        System.out.println("All tests passed.");
    }
}
