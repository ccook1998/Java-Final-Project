public class Player {
    private String playerName;  // The name of the player
    private int score;          // The player's score

    // Constructor to initialize a player with their name and a default score of 0
    public Player(String playerName) {
        this.playerName = playerName;
        this.score = 0;
    }

    // Method to increment the player's score by 1
    public void incrementScore() {
        score++;
    }

    // Getter for the player's current score
    public int getScore() {
        return score;
    }

    // Setter for the player's score (useful for direct score updates)
    public void setScore(int score) {
        this.score = score;
    }

    // Getter for the player's name
    public String getPlayerName() {
        return playerName;
    }

    // Override the equals method to compare players by their name
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Player player = (Player) obj;
        return playerName.equals(player.playerName);
    }

    // Override the hashCode method to ensure consistency with equals
    @Override
    public int hashCode() {
        return playerName.hashCode();
    }

    // Optional: Method to return a string representation of the player for debugging or display purposes
    @Override
    public String toString() {
        return "Player{" +
               "playerName='" + playerName + '\'' +
               ", score=" + score +
               '}';
    }
}
