import java.util.ArrayList;
import java.util.List;

public class HangmanLogic {
    private String secretWord;
    private StringBuilder displayedWord;
    private List<Character> wrongGuesses = new ArrayList<>();
    private List<Character> guessedLetters = new ArrayList<>(); // Track guessed letters
    private final int maxAttempts = 6;

    public HangmanLogic(String word) {
        this.secretWord = word.toUpperCase();
        this.displayedWord = new StringBuilder("_ ".repeat(secretWord.length()));
    }

    // Method to handle a guess
    public boolean guessLetter(char letter) {
        letter = Character.toUpperCase(letter);

        // Check if the letter has already been guessed
        if (guessedLetters.contains(letter)) {
            return false; // Letter already guessed, return false to indicate repeat guess
        }

        // Add the letter to the list of guessed letters
        guessedLetters.add(letter);

        if (secretWord.contains(String.valueOf(letter))) {
            updateDisplayedWord(letter);
            return true; // Correct guess
        } else {
            wrongGuesses.add(letter);
            return false; // Incorrect guess
        }
    }

    // Update the displayed word for correct guesses
    private void updateDisplayedWord(char letter) {
        for (int i = 0; i < secretWord.length(); i++) {
            if (secretWord.charAt(i) == letter) {
                displayedWord.setCharAt(i * 2, letter);
            }
        }
    }

    // Check if the player has won
    public boolean isGameWon() {
        return !displayedWord.toString().contains("_");
    }

    // Check if the player has lost
    public boolean isGameOver() {
        return wrongGuesses.size() >= maxAttempts;
    }

    // Method to check if a letter has already been guessed
    public boolean isLetterGuessed(char letter) {
        return guessedLetters.contains(letter);
    }

    // Getter for the displayed word
    public String getDisplayedWord() {
        return displayedWord.toString();
    }

    // Getter for remaining attempts
    public int getRemainingAttempts() {
        return maxAttempts - wrongGuesses.size();
    }

    // Getter for the secret word (useful for game over scenarios)
    public String getSecretWord() {
        return secretWord;
    }
}
