import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Scoreboard {
    private List<Player> players;  // List to store player information

    // Constructor to initialize the players list
    public Scoreboard() {
        players = new ArrayList<>();
    }

    // Method to add a new player to the scoreboard
    public void addPlayer(Player player) {
        // Check if player is null before adding
        if (player != null) {
            players.add(player);
        }
    }

    // Method to update a player's score (example logic for incrementing score)
    public void updateScore(Player player, int newScore) {
        // Ensure the player exists in the list before updating the score
        for (Player p : players) {
            if (p.equals(player)) {
                p.setScore(newScore);  // Assuming Player has a setScore method
                break;
            }
        }
    }

    // Method to return a list of top high-scoring players, sorted by score
    public List<Player> getHighScores() {
        // Sort the players by their score in descending order
        players.sort(Comparator.comparingInt(Player::getScore).reversed());
        
        // Return the top 5 players, or fewer if there aren't enough players
        return players.size() > 5 ? players.subList(0, 5) : players;
    }
}
