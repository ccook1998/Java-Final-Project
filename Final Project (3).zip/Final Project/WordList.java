import java.util.List;
import java.util.Random;

public class WordList {
    private List<String> easyWords;
    private List<String> mediumWords;
    private List<String> hardWords;

    // Constructor that initializes lists of words based on difficulty
    public WordList(List<String> easyWords, List<String> mediumWords, List<String> hardWords) {
        if (easyWords == null || mediumWords == null || hardWords == null) {
            throw new IllegalArgumentException("Word lists cannot be null.");
        }
        if (easyWords.isEmpty() || mediumWords.isEmpty() || hardWords.isEmpty()) {
            throw new IllegalArgumentException("Word lists cannot be empty.");
        }
        this.easyWords = easyWords;
        this.mediumWords = mediumWords;
        this.hardWords = hardWords;
    }

    // Method to return a random word based on the difficulty level
    public String getRandomWord(String difficulty) {
        Random random = new Random();
        switch (difficulty.toLowerCase()) {
            case "easy":
                return easyWords.get(random.nextInt(easyWords.size()));
            case "medium":
                return mediumWords.get(random.nextInt(mediumWords.size()));
            case "hard":
                return hardWords.get(random.nextInt(hardWords.size()));
            default:
                throw new IllegalArgumentException("Invalid difficulty level: " + difficulty);
        }
    }
}
