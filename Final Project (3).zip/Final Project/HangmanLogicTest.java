import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HangmanLogicTest {

    @Test
    public void testCorrectGuess() {
        HangmanLogic game = new HangmanLogic("apple");
        assertTrue(game.guessLetter('a'), "Correct guess should return true");
        assertEquals("A _ _ _ _ ", game.getDisplayedWord(), "Displayed word not updated correctly for correct guess");
    }

    @Test
    public void testIncorrectGuess() {
        HangmanLogic game = new HangmanLogic("apple");
        assertFalse(game.guessLetter('z'), "Incorrect guess should return false");
        assertEquals(5, game.getRemainingAttempts(), "Remaining attempts not updated correctly for incorrect guess");
    }

    @Test
    public void testPreventRepeatedGuesses() {
        HangmanLogic game = new HangmanLogic("apple");
        game.guessLetter('a');
        assertFalse(game.guessLetter('a'), "Repeated guess should return false");
    }

    @Test
    public void testWinCondition() {
        HangmanLogic game = new HangmanLogic("apple");
        game.guessLetter('a');
        game.guessLetter('p');
        game.guessLetter('l');
        game.guessLetter('e');
        assertTrue(game.isGameWon(), "Game should be won after all correct guesses");
    }

    @Test
    public void testGameOverCondition() {
        HangmanLogic game = new HangmanLogic("apple");
        game.guessLetter('z');
        game.guessLetter('x');
        game.guessLetter('q');
        game.guessLetter('r');
        game.guessLetter('t');
        game.guessLetter('y');
        assertTrue(game.isGameOver(), "Game should be over after 6 incorrect guesses");
    }

    @Test
    public void testSecretWordRevealOnGameOver() {
        HangmanLogic game = new HangmanLogic("apple");
        game.guessLetter('z');
        game.guessLetter('x');
        game.guessLetter('q');
        game.guessLetter('r');
        game.guessLetter('t');
        game.guessLetter('y');
        assertEquals("apple", game.getSecretWord(), "Secret word should be revealed on game over");
    }
}
