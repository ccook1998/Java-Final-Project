import java.util.Arrays;
import java.util.List;

public class WordListTest {
    public static void main(String[] args) {
        // Step 1: Create three lists of words for easy, medium, and hard difficulty
        List<String> easyWords = Arrays.asList("apple", "banana", "cherry");
        List<String> mediumWords = Arrays.asList("orange", "pear", "grape");
        List<String> hardWords = Arrays.asList("pineapple", "watermelon", "strawberry");

        // Step 2: Create an instance of the WordList class, passing in the three lists
        WordList wordList = new WordList(easyWords, mediumWords, hardWords);

        // Test 1: Ensure that the word list for easy words is not empty
        assert easyWords.size() > 0 : "Easy word list should not be empty";

        // Test 2: Test that getRandomWord(String) returns a word that is part of the easy word list
        String randomWord = wordList.getRandomWord("easy");  // Pass the difficulty level
        assert easyWords.contains(randomWord) : "Random word should be one of the easy words";

        // Test 3: Call getRandomWord(String) multiple times to check that it always returns a valid word
        for (int i = 0; i < 10; i++) {
            String word = wordList.getRandomWord("easy");  // Pass the difficulty level
            assert easyWords.contains(word) : "Each random word should be in the easy word list";
        }

        // Test 4: (Optional) Test that getRandomWord(String) doesn't return the same word twice in a row
        String previousWord = wordList.getRandomWord("easy");  // Pass the difficulty level
        for (int i = 0; i < 5; i++) {
            String newWord = wordList.getRandomWord("easy");  // Pass the difficulty level
            assert !previousWord.equals(newWord) : "Random words should not repeat consecutively";
            previousWord = newWord;
        }

        // Output message indicating that all tests passed
        System.out.println("All tests passed.");
    }
}
