import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class ScoreboardTest {

    @Test
    public void testAddPlayer() {
        Scoreboard scoreboard = new Scoreboard();
        Player player = new Player("John");
        scoreboard.addPlayer(player);
        List<Player> highScores = scoreboard.getHighScores();
        assertTrue(highScores.contains(player), "Player should be added to the scoreboard");
    }

    @Test
    public void testUpdatePlayerScore() {
        Scoreboard scoreboard = new Scoreboard();
        Player player = new Player("John");
        scoreboard.addPlayer(player);
        player.incrementScore();
        scoreboard.updateScore(player, player.getScore());
        assertEquals(1, scoreboard.getHighScores().get(0).getScore(), "Player's score should be updated");
    }

    @Test
    public void testHighScoreOrder() {
        Scoreboard scoreboard = new Scoreboard();
        Player player1 = new Player("John");
        Player player2 = new Player("Alice");
        player1.setScore(5);
        player2.setScore(10);
        scoreboard.addPlayer(player1);
        scoreboard.addPlayer(player2);
        List<Player> highScores = scoreboard.getHighScores();
        assertEquals(player2, highScores.get(0), "Player with the highest score should be listed first");
    }
}
