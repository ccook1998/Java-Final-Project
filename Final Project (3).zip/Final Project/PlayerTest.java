import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {

    @Test
    public void testInitialScore() {
        Player player = new Player("John");
        assertEquals(0, player.getScore(), "Initial score should be 0");
    }

    @Test
    public void testIncrementScore() {
        Player player = new Player("John");
        player.incrementScore();
        assertEquals(1, player.getScore(), "Score should be incremented to 1");
    }

    @Test
    public void testSetScore() {
        Player player = new Player("John");
        player.setScore(5);
        assertEquals(5, player.getScore(), "Score should be set to 5");
    }

    @Test
    public void testPlayerEquality() {
        Player player1 = new Player("John");
        Player player2 = new Player("John");
        assertEquals(player1, player2, "Players with the same name should be equal");
    }
}
